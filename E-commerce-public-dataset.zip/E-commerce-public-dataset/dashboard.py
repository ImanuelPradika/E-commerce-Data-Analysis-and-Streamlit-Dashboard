conda activate main-ds
pip install streamlit babel